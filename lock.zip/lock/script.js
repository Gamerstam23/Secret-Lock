const correctPassword = "mypassword"; // Set your password here
let hiddenFiles = [];

function checkPassword() {
    const passwordInput = document.getElementById('passwordInput').value;
    const errorMessage = document.getElementById('errorMessage');

    if (passwordInput === correctPassword) {
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('vault').style.display = 'block';
        errorMessage.textContent = '';
    } else {
        errorMessage.textContent = 'Incorrect Password';
    }
}

function hideFiles() {
    const fileName = prompt("Enter the name of the file to hide:");
    if (fileName) {
        hiddenFiles.push(fileName);
        alert(${fileName} has been hidden.);
        document.getElementById('fileContainer').innerHTML += <p>${fileName}</p>;
    }
}

function showFiles() {
    if (hiddenFiles.length === 0) {
        alert("No files hidden.");
        return;
    }
    
    alert("Hidden Files:n" + hiddenFiles.join("n"));
}

function logout() {
    document.getElementById('vault').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
}